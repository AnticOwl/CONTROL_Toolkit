# CONTROL Toolkit v0.5c

In-game toolkit for CONTROL (DX12).

## Install

1. Extract this ZIP.
2. Copy `IGCSRelay.addon64` into the same ReShade add-ons folder as your existing `IgcsConnector.addon64`.
3. Start CONTROL in DX12 mode and load into the game.
4. Run `ControlToolkitInjector.exe` and press F10 to show or hide the toolkit.

Keep `ControlToolkit.dll` beside `ControlToolkitInjector.exe`. Inject once per game session.

## Frans' IGCSDOF

The Frans DOF workflow requires IGCS Relay. The Relay file is included in this ZIP; place it beside `IgcsConnector.addon64` in the ReShade add-ons folder. Enable both add-ons in ReShade. In CONTROL Toolkit, enable the IGCSDOF named-pipe provider; start the DOF session from the IGCS Connector add-on.

## Source and notes

Source code: https://github.com/AnticOwl/CONTROL_Toolkit/tree/main/source/v0.5c

Release notes: `CHANGES_v0.5b_RenderSettingsHook.md` and `CHANGES_v0.5c_CleanHotsamplingUI.md`.
