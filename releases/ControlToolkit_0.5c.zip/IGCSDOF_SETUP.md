# Frans' IGCSDOF setup — CONTROL Toolkit v0.5c

Frans' depth-of-field workflow uses IGCS Relay together with the IGCS Connector ReShade add-on.

1. Extract the CONTROL Toolkit release ZIP.
2. Copy `IGCSRelay.addon64` from the ZIP into the same ReShade add-ons folder as `IgcsConnector.addon64`.
3. In ReShade, make sure both **IGCS Connector** and **IGCSRelay** are enabled.
4. Start CONTROL in DX12 mode, enter the game, then run `ControlToolkitInjector.exe`.
5. In CONTROL Toolkit's **IGCSDOF** tab, enable the named-pipe provider. Start the DOF session from **IGCS Connector → Depth of Field control**.

The Relay belongs with the Connector in ReShade's add-ons folder; it does not go beside the Toolkit injector or DLL.
